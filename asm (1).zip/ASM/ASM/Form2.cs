﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ASM
{
    public partial class Form2 : Form
    {
        // Constructor mặc định
        public Form2()
        {
            InitializeComponent();
        }

        // Constructor để nhận dữ liệu từ Form1
        public Form2(string customerName, string typeOfCustomer, int numberOfPeople, double consumption, double totalAmount)
        {
            InitializeComponent();

            // Gán dữ liệu nhận được vào các Label
            lblCustomerName.Text = customerName;
            lblCustomerType.Text = typeOfCustomer;
            lblConsumption.Text = consumption.ToString("N0") + " m³";
            lblTotalAmount.Text = totalAmount.ToString("N0") + " VNĐ";

            // Chỉ hiển thị "Số người" nếu là khách hàng hộ gia đình
            if (typeOfCustomer == "Household customer")
            {
                lblPeople.Text = numberOfPeople.ToString();
            }
            else
            {
                // Nếu không phải, ẩn cả nhãn "Number of people:" và giá trị của nó
                lblPeople.Visible = false; // Thay "label3" bằng TÊN THẬT của nhãn "Number of people:"
                lblPeople.Visible = false;
            }
        }
        private void lblPeople_Click(object sender, EventArgs e)
        {

        }
    }
}
